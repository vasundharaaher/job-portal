from django.urls import path,include
from . import views

urlpatterns = [
    path("",views.IndexPage,name="index"),
    path("base1",views.BasePage,name="base1"),
    path("login/",views.SigupPage,name="login"),
    path("register/",views.RegisterUser,name="register"),
    path("otp/",views.OTPPage,name="otp"),
    path("otpverify/",views.Otpverify,name="otpverify"),
    path("loginuser/",views.LoginUser,name="loginuser"),
    path("about/", views.AboutView, name="about"),
    path("profile/<int:pk>", views.ProfilePage, name="profile"),
    path("updateprofile/<int:pk>", views.UpdateProfile, name="updateprofile"),
    path("candidatejoblistpage/",views.CandidateJobListPage,name="candidatejoblistpage"),
    path("jobapplypage/<int:pk>/",views.JobApplyPage,name="jobapplypage"),
    path("applyjob/<int:pk>",views.ApplyJobPage,name="applyjob"),
    path("logout/", views.logout, name="logout"),
    path("appliedjoblist/",views.AppliedJobs,name="appliedjoblist"),


    ############### company #############

    path("companyindexpage/",views.CompanyIndexPage, name="companyindexpage"),
    path("aboutcompany/", views.AboutViewCompany, name="aboutcompany"),
    path("companyprofile/<int:pk>",views.CompanyProfile,name="companyprofile"),
    path("updatecompanyprofile/<int:pk>",views.UpdateCompanyProfile, name="updatecompanyprofile"),
    path("jobdetailspage/<int:pk>",views.JobDetailsPage,name="jobdetailspage"),
    path("jobdetailsubmit/",views.JobDetailSubmit,name="jobdetailsubmit"),
    path("jobpostlist/",views.JobPostList,name="jobpostlist"),
    path("jobapplylist/",views.JobApplyList,name="jobapplylist"),
    path('logout_company/', views.logout_company, name='logout_company'),
    path("CompanyJobListPage/",views.CompanyJobListPage,name="CompanyJobListPage"),
   path("applications/<int:id>/resume/", views.download_resume, name="download_resume"),

    ######################### Admin ##########################
     path('adminpage/', views.AdminPage, name='adminpage'),
     path('adminindexpage/', views.AdminIndexPage, name='adminindexpage'),
     path('adminloginpage/', views.AdminLoginPage, name='adminloginpage'),
     path('admincandidatelist/',views.AdminCandidateList, name='admincandidatelist'),
     path('admincompanylist/',views.AdminCompanyList, name='admincompanylist'),
     path('candidatedelete/<int:pk>',views.CandidateDelete, name='candidatedelete'),
     path('verifycompany/<int:pk>',views.VerifyCompany, name='verifycompany'),

]