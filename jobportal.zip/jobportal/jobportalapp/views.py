from django.shortcuts import render,redirect
from .models import *
from random import randint
from django.contrib import messages
from django.http import HttpResponse , HttpResponseForbidden
from django.db.models import Count
import os
from django.http import FileResponse, Http404
from django.shortcuts import get_object_or_404



# Create your views here.
def BasePage(request):
    return render(request,"app/base1.html")


def IndexPage(request):
    categories = JobDetails.objects.values('jobcategory').annotate(count=Count('id'))

    # Clean category keys to make them template-safe
    categorydict = {
        cat['jobcategory'].replace(" ", "_").replace("&", "and"): cat['count']
        for cat in categories
    }

    return render(request, 'app/index.html', {'categorydict': categorydict})


def SigupPage(request):
    return render(request,"app/login.html")

def AboutView(request):
    return render(request,"app/about.html")  # Adjust the path as necessary

def ProfileView(request):
    return render(request,"app/profile.html")  # Adjust the path as necessary

def RegisterUser (request):
    if request.method == 'POST':
        role = request.POST.get('role')  # Use get() to avoid MultiValueDictKeyError
        if role == "Candidate":
            fname = request.POST['fname']
            lname = request.POST['lname']
            email = request.POST['email']
            password = request.POST['password']
            cpassword = request.POST['cpassword']

            user = UserMaster.objects.filter(email=email)

            if user.exists():  # Use exists() to check if the user already exists
                message = "User  already exists"
                return render(request, "app/login.html", {'msg': message})
            else:
                if password == cpassword:
                    otp = randint(100000, 999999)
                    newuser = UserMaster.objects.create(role=role, otp=otp, email=email, password=password)
                    newcand = Candidate.objects.create(user_id=newuser, firstname=fname, lastname=lname)
                    return render(request, "app/otpverify.html", {'email': email})
                else:
                    message = "Passwords do not match"
                    return render(request, "app/register.html", {'msg': message})  # Return to registration with an error
                

        elif role == "Company":
            fname = request.POST['fname']
            lname = request.POST['lname']
            email = request.POST['email']
            password = request.POST['password']
            cpassword = request.POST['cpassword']

            user = UserMaster.objects.filter(email=email)

            if user.exists():  # Use exists() to check if the user already exists
                message = "User  already exists"
                return render(request, "app/login.html", {'msg': message})
            else:
                if password == cpassword:
                    otp = randint(100000, 999999)
                    newuser = UserMaster.objects.create(role=role, otp=otp, email=email, password=password)
                    newcmpny = Company.objects.create(user_id=newuser, firstname=fname, lastname=lname)
                    return render(request, "app/otpverify.html", {'email': email})
                else:
                    message = "Passwords do not match"
                    return render(request, "app/register.html", {'msg': message})  # Return to registration with an error
        else:
            message = "Invalid role selected"
            return render(request, "app/register.html", {'msg': message})  # Return to registration with an error
    else:
        # If the request method is GET, render the registration form
        return render(request, "app/register.html")  # Ensure this returns an HttpResponse



def OTPPage(request):
    return render(request,"app/otpverify.html")



def Otpverify(request):
    if request.method == 'POST':
        email = request.POST['email']
        otp = int(request.POST['otp'])

        user = UserMaster.objects.get(email=email)

        if user:
            if user.otp == otp:
                message = "OTP verify successfully"
                return render(request,"app/login.html",{'msg':message})
            else:
                message = "OTP is incorrect"
                return render(request,"app/otpverify.html",{'msg':message})
        else:
            return render(request,"app/register.html")



def LoginUser (request):
    if request.method == 'POST':
        role = request.POST.get('role')  # Use get() to avoid MultiValueDictKeyError
        if role == "Candidate":
            email = request.POST.get('email')  # Assuming you meant to get the email here
            password = request.POST.get('password')

            try:
                user = UserMaster.objects.get(email=email)
                if password == user.password and user.role == "Candidate":
                    can = Candidate.objects.get(user_id=user)
                    request.session['id'] = user.id
                    request.session['role'] = user.role
                    request.session['firstname'] = can.firstname
                    request.session['lastname'] = can.lastname
                    request.session['email'] = user.email
                    
                    
                    return redirect("index")  # Redirect to index without arguments
                else:
                    message = "Password does not match or user is not a candidate"
                    return render(request, "app/login.html", {'msg': message})
            except UserMaster.DoesNotExist:
                message = "User  does not exist"
                return render(request, "app/login.html", {'msg': message})


        elif role == "Company":
            email = request.POST.get('email')  # Assuming you meant to get the email here
            password = request.POST.get('password')
            try:
                user = UserMaster.objects.get(email=email)
                if password == user.password and user.role == "Company":
                    cmpny = Company.objects.get(user_id=user)
                    request.session['id'] = user.id
                    request.session['role'] = user.role
                    request.session['firstname'] = cmpny.firstname
                    request.session['lastname'] = cmpny.lastname
                    request.session['email'] = user.email
                    
                    return render(request,"app/company/index-company.html") # Redirect to Admin page without arguments
                else:
                    message = "Password does not match or user is not a company"
                    return render(request, "app/login.html", {'msg': message})
            except UserMaster.DoesNotExist:
                message = "User  does not exist"
                return render(request, "app/login.html", {'msg': message})

        else:
            message = "Invalid role selected"
            return render(request, "app/login.html", {'msg': message})  # Return to login with an error
    else:
        # If the request method is GET, render the login form
        return render(request, "app/login.html")  # Ensure this returns an HttpResponse



def logout(request):
    if 'id' in request.session:
        # Clear session data
        request.session.flush()  # This clears all session data safely
        messages.success(request, "You have successfully logged out.")
    else:
        messages.error(request, "You are not logged in.")
    return render(request, "app/index.html")
        


#####################################################################################

def ProfilePage(request, pk):
    try:
        user = UserMaster.objects.get(pk=pk)
        
        # Check the role of the user
        if user.role == "Candidate":
            try:
                can = Candidate.objects.get(user_id=user)
                return render(request, "app/profile.html", {'user': user, 'can': can})
            except Candidate.DoesNotExist:
                message = "Candidate profile does not exist"
                return render(request, "app/register.html", {'msg': message})
        
        else:
            message = "Invalid user role"
            return render(request, "app/register.html", {'msg': message})
    
    except UserMaster.DoesNotExist:
        message = "User does not exist"
        return render(request, "app/register.html", {'msg': message})



def UpdateProfile(request, pk):
    try:
        user = UserMaster.objects.get(pk=pk)
        
        # Handle candidate profile update
        if user.role == "Candidate":
            try:
                can = Candidate.objects.get(user_id=user)
                
                # Update candidate fields from form data
                can.firstname = request.POST.get('fname', can.firstname)
                can.lastname = request.POST.get('lname', can.lastname)
                can.dob = request.POST.get('dob', can.dob)
                user.email = request.POST.get('email', user.email) 
                can.state = request.POST.get('state', can.state)
                can.city = request.POST.get('city', can.city)
                can.job_type = request.POST.get('job_type', can.job_type)
                can.jobcategory = request.POST.get('jobcategory', can.jobcategory)
                can.highesedu = request.POST.get('highesedu', can.highesedu)
                can.experience = request.POST.get('experience', can.experience)
                can.website = request.POST.get('website', can.website)
                can.shift = request.POST.get('shift', can.shift)
                can.min_salary = request.POST.get('min_salary', can.min_salary)
                can.max_salary = request.POST.get('max_salary', can.max_salary)
                can.contact = request.POST.get('contact', can.contact)
                can.gender = request.POST.get('gender', can.gender)
                can.address = request.POST.get('address', can.address)
                can.country = request.POST.get('country', can.country)
                
                # Handle profile picture upload
                if 'profile_pic' in request.FILES:
                    can.profile_pic = request.FILES['profile_pic']
                
                # Save the updated candidate profile
                can.save()
                
                return render(request, "app/profile.html", {'user': user, 'can': can, 'msg': 'Profile updated successfully.'})
            
            except Candidate.DoesNotExist:
                return render(request, "app/register.html", {'msg': 'Candidate profile does not exist.'})
        
        
        # Redirect for invalid user role
        return render(request, "app/login.html", {'msg': 'Invalid role for this user.'})
    
    except UserMaster.DoesNotExist:
        return render(request, "app/register.html", {'msg': 'User does not exist.'})
    
    except Exception as e:
        # General error handling for unexpected exceptions
        return render(request, "app/error.html", {'msg': f"An unexpected error occurred: {e}"})


def CandidateJobListPage(request):
    all_job = JobDetails.objects.all()
    return render(request, "app/job-list.html",{'alljob':all_job})


def JobApplyPage(request,pk):
    user = UserMaster.objects.get(id=request.session['id'])
    if user :
        can = Candidate.objects.get(user_id=user)
        job = JobDetails.objects.get(id=pk)
    return render(request, "app/apply-page.html",{'user':user,'can':can,'job':job})


def ApplyJobPage(request, pk):
    user_id = request.session.get('id')
    if not user_id:
        return render(request, "app/apply-page.html", {'msg': "Session expired. Please login again."})

    try:
        can = Candidate.objects.get(user_id=user_id)
        job = JobDetails.objects.get(id=pk)
    except (Candidate.DoesNotExist, JobDetails.DoesNotExist):
        return render(request, "app/apply-page.html", {'msg': "Candidate or Job not found."})

    if request.method == 'POST':
        edu = request.POST.get('education')
        exp = request.POST.get('experience')
        web = request.POST.get('website')
        gender = request.POST.get('gender')
        jobcategory = request.POST.get('jobcategory')
        expectations = request.POST.get('expectations') 
        shift = request.POST.get('shift')
        resume = request.FILES.get('resume')

        # Validation
        if not resume or not edu or not exp:
            return render(request, "app/apply-page.html", {
                'msg': 'Please fill all required fields.',
                'job': job,
                'can': can,
                'user': request.user
            })

        try:
            exp = int(exp)
            expectations = int(expectations)
        except ValueError:
            return render(request, "app/apply-page.html", {
                'msg': 'Experience and Expectations must be numeric values.',
                'job': job,
                'can': can,
                'user': request.user
            })

        ApplyList.objects.create(
            candidate=can,
            job=job,
            education=edu,
            website=web,
            experience=exp,
            expectations=expectations,
            shift=shift,
            gender=gender,
            
            resume=resume
        )

        return render(request, "app/apply-page.html", {
            'msg': "Applied for job successfully!",
            'job': job,
            'can': can,
            'user': request.user
        })

    # GET request
    return render(request, "app/apply-page.html", {
        'job': job,
        'can': can,
        'user': request.user
    })


def AppliedJobs(request):
    user_id = request.session.get('id')
    if not user_id:
        return redirect('login')

    try:
        user = UserMaster.objects.get(id=user_id)
        candidate = Candidate.objects.get(user_id=user)

        # Fetch applied jobs with job and company info
        appliedjobs = ApplyList.objects.filter(candidate=candidate).select_related('job','job__company_id')

        return render(request, 'app/jobappliedlist.html', {'appliedjobs': appliedjobs})

    except Candidate.DoesNotExist:
        return redirect('index')




######################## Company ##########################



def CompanyIndexPage(request):
    categories = JobDetails.objects.values('jobcategory').annotate(count=Count('id'))

    # Clean category keys to make them template-safe
    categorydict = {
        cat['jobcategory'].replace(" ", "_").replace("&", "and"): cat['count']
        for cat in categories
    }

    return render(request, 'app/company/index-company.html', {'categorydict': categorydict})



def AboutViewCompany(request):
    return render(request,"app/company/about-company.html")  # Adjust the path as necessary

def CompanyProfile(request,pk):
    try:
        user = UserMaster.objects.get(pk=pk)
        
        # Check the role of the user
        if user.role == "Company":
            try:
                cmpny = Company.objects.get(user_id=user)
                return render(request, "app/company/profile-company.html", {'user': user, 'cmpny': cmpny})
            except Company.DoesNotExist:
                message = "Company profile does not exist"
                return render(request, "app/register.html", {'msg': message})
        
        else:
            message = "Invalid user role"
            return render(request, "app/register.html", {'msg': message})
    
    except UserMaster.DoesNotExist:
        message = "User does not exist"
        return render(request, "app/register.html", {'msg': message})
   


def UpdateCompanyProfile(request,pk):
        
    try:
        user = UserMaster.objects.get(pk=pk)
        # Handle company profile update
        if user.role == "Company":
            try:
                cmpny = Company.objects.get(user_id=user)
                
                # Update company fields
                cmpny.firstname = request.POST.get('firstname', cmpny.firstname)
                cmpny.lastname = request.POST.get('lastname', cmpny.lastname)
                cmpny.company_name = request.POST.get('company_name', cmpny.company_name)
                cmpny.state = request.POST.get('state', cmpny.state)
                cmpny.city = request.POST.get('city', cmpny.city)
                cmpny.contact = request.POST.get('contact', cmpny.contact)
                cmpny.address = request.POST.get('address', cmpny.address)
                cmpny.country = request.POST.get('country', cmpny.country)
                cmpny.companydscription = request.POST.get('companydscription', cmpny.companydscription)
                cmpny.website = request.POST.get('website', cmpny.website)
                
                # Handle company logo upload
                if 'logo_pic' in request.FILES:
                    cmpny.logo_pic = request.FILES['logo_pic']
                
                # Save the updated company profile  
                cmpny.save()
                url = f"/companyprofile/{pk}"
                return redirect(url)
            
            except Company.DoesNotExist:
                return render(request, "app/register.html", {'msg': 'Company profile does not exist.'})

        
        # Redirect for invalid user role
        return redirect("loginuser")
    
    except UserMaster.DoesNotExist:
        return render(request, "app/register.html", {'msg': 'User does not exist.'})
    
    except Exception as e:
        # General error handling for unexpected exceptions
        return render(request, "app/error.html", {'msg': f"An unexpected error occurred: {e}"})



def JobDetailsPage(request,pk):
    try:
        user = UserMaster.objects.get(pk=pk)
        
        # Check the role of the user
        if user.role == "Company":
            try:
                cmpny = Company.objects.get(user_id=user)
                return render(request, "app/company/job-details.html", {'user': user, 'cmpny': cmpny})
            except Company.DoesNotExist:
                message = "Company profile does not exist"
                return render(request, "app/register.html", {'msg': message})
        
        else:
            message = "Invalid user role"
            return render(request, "app/register.html", {'msg': message})
    
    except UserMaster.DoesNotExist:
        message = "User does not exist"
        return render(request, "app/register.html", {'msg': message})
   



def JobDetailSubmit(request):
    user = UserMaster.objects.get(id=request.session['id'])
    

    if user.role == "Company":
        comp = Company.objects.get(user_id=user)
        jobname = request.POST.get('jobname')
        companyname = request.POST.get('companyname')
        companyaddress = request.POST.get('companyaddress')
        jobdescription = request.POST.get('jobdescription')
        qualification = request.POST.get('qualification')
        responsibilties = request.POST.get('responsibilties')
        location = request.POST.get('location')
        companywebsite = request.POST.get('companywebsite')
        logo = request.FILES.get('logo')
        companyemail = request.POST.get('companyemail')
        companycontact = request.POST.get('companycontact')
        salarypackage = request.POST.get('salarypackage')
        experience = request.POST.get('experience')
        jobcategory = request.POST.get('jobcategory')
        job_type = request.POST.get('job_type')

        newjob = JobDetails.objects.create(
            company_id=comp,
            jobname=jobname,
            companyname=companyname,
            companyaddress=companyaddress,
            jobdescription=jobdescription,
            qualification=qualification,
            responsibilties=responsibilties,
            location=location,
            companywebsite=companywebsite,
            companyemail=companyemail,
            companycontact=companycontact,
            salarypackage=salarypackage,
            experience=experience,
            job_type=job_type,
            jobcategory=jobcategory,
            logo=logo
        )


        message = "Job Post Successfully"
        return render(request,"app/company/job-details.html",{'msg': message})


def JobPostList(request):
    user_id = request.session.get('id')
    
    # Get the company user
    user = UserMaster.objects.get(id=user_id)
    company_id = Company.objects.get(user_id=user)

    # Filter only jobs posted by this company
    all_job = JobDetails.objects.filter(company_id=company_id)
    return render(request,"app/company/job-post-list.html",{'alljob':all_job})

def JobApplyList(request):
    user_id = request.session.get('id')
    user = UserMaster.objects.get(id=user_id)
    company = Company.objects.get(user_id=user)

    # Filter applications where job.company_id == current company
    applications = ApplyList.objects.filter(job__company_id=company).select_related('job', 'candidate')

    return render(request, "app/company/applyjoblist.html", {'alljob': applications})


def download_resume(request, id):
    application = get_object_or_404(ApplyList, id=id)

    if not application.resume:
        raise Http404("Resume not found.")

    filename = os.path.basename(application.resume.name)
    return FileResponse(
        application.resume.open("rb"),
        as_attachment=True,
        filename=filename
    )


def CompanyJobListPage(request):
    all_job = JobDetails.objects.all()
    return render(request, "app/company/job-list.html",{'alljob':all_job})






def logout_company(request):
    if 'id' in request.session:
        # Clear session data
        request.session.flush()  # This clears all session data safely
        messages.success(request, "You have successfully logged out.")
    else:
        messages.error(request, "You are not logged in.")
    
    return redirect('index')


######################################### Admin #######################################


def AdminPage(request):
    return render(request,"app/admin/login-admin.html")

def AdminIndexPage(request):
    if 'username' in request.session and 'password' in request.session:
        return render(request,"app/admin/index.html")
    else:
        return redirect('adminloginpage')

def AdminLoginPage(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        if username == "admin" and password == "admin":
            request.session['username'] = username
            request.session['password'] = password
            return render(request, "app/admin/base1-admin.html")
        else:
            return HttpResponse("Invalid credentials")

    return render(request, "app/admin/login-admin.html")  # or wherever your login form is


def AdminCandidateList(request):
    all_candidate = UserMaster.objects.filter(role="Candidate")
    return render(request,"app/admin/candidatelist.html",{'allcand':all_candidate})

def AdminCompanyList(request):
    all_company = UserMaster.objects.filter(role="Company")
    return render(request,"app/admin/companylist.html",{'allcomp':all_company})

def CandidateDelete(reqest,pk):
    user = UserMaster.objects.get(pk=pk)
    user.delete()
    return redirect('admincandidatelist')


def VerifyCompany(request,pk):
    company = UserMaster.objects.get(pk=pk)
    if company:
        return render(request,"app/admin/verify.html",{'company':company})